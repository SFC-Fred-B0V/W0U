<script setup>

</script>

<template>
  <div class="title">
    Fred's expense tracker
  </div>
</template>

<style scoped>
.title {
  color: green;
  font-size: 40px;
}
</style>
